const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();
const PORT = 3000;

mongoose.connect('mongodb://localhost:27017/GameCenter', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const session = require('express-session');

app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // set to true in production with HTTPS
}));

// Serve static files (optional, if you have CSS/JS separately)
app.use(express.static(path.join(__dirname, 'Javascript Front-End')));

// Serve index.html manually
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'Javascript Front-End', 'index.html'));
});

app.get('/users', async (req, res) => {
  try {
    const users = await mongoose.connection.db.collection('users').find().toArray();
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).send('Error fetching users');
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
