The game website group for APW_JS
